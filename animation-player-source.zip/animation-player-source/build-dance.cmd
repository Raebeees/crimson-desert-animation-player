@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /DUNICODE /D_UNICODE /LD /I"C:\Modding\animation-dependencies\engine-adapter" /I"%~dp0controller" /I"%~dp0controller\minhook\include" client.cpp dance_adapter.cpp /Fe:DanceModule.asi /link /IMPLIB:DanceModule.lib user32.lib gdi32.lib dwmapi.lib ole32.lib xaudio2.lib xinput.lib bcrypt.lib
