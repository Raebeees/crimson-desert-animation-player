@echo off
setlocal
cd /d "%~dp0"
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
if not exist shared-tests mkdir shared-tests
for %%T in (idle_shared host movement_wrapper selector ce_compat comma launch) do (
 cl /nologo /std:c++17 /EHsc /W4 /WX /I. /Iminhook\include %%T_test.cpp /Fe:shared-tests\%%T_test.exe /Fo:shared-tests\%%T_test.obj /link user32.lib bcrypt.lib >>shared-tests\build.log 2>&1
 if errorlevel 1 exit /b 1
 shared-tests\%%T_test.exe >>shared-tests\results.txt 2>&1
 if errorlevel 1 exit /b 1
)
exit /b 0
