@echo off
setlocal
cd /d "%~dp0"
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
set "MH=minhook"
cl /nologo /c /MT /O2 /I"%MH%\include" "%MH%\src\hook.c" "%MH%\src\buffer.c" "%MH%\src\trampoline.c" "%MH%\src\hde\hde64.c"
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /LD /I"%MH%\include" /I"." /I"." /I"." /I"." bridge.cpp hook.obj buffer.obj trampoline.obj hde64.obj bcrypt.lib user32.lib /Fe:TidebreakerFlight204.asi
if errorlevel 1 exit /b 1
exit /b %errorlevel%
