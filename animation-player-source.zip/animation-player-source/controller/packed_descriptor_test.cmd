@echo off
cd /d "%~dp0"
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX packed_descriptor_test.cpp /Fe:packed_descriptor_test.exe
if errorlevel 1 exit /b 1
packed_descriptor_test.exe
exit /b %errorlevel%


