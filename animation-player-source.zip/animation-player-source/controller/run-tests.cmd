@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Od user32.lib /Fe:all_headers_test.exe /Fo:all_headers_test.obj "all_headers_test.cpp"
if errorlevel 1 exit /b 1
all_headers_test.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Od user32.lib /Fe:host_test.exe /Fo:host_test.obj "host_test.cpp"
if errorlevel 1 exit /b 1
host_test.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Od user32.lib /Fe:readiness_test.exe /Fo:readiness_test.obj "readiness_test.cpp"
if errorlevel 1 exit /b 1
readiness_test.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Od user32.lib /Fe:selector_test.exe /Fo:selector_test.obj "selector_test.cpp"
if errorlevel 1 exit /b 1
selector_test.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Od user32.lib /Fe:movement_wrapper_test.exe /Fo:movement_wrapper_test.obj "movement_wrapper_test.cpp"
if errorlevel 1 exit /b 1
movement_wrapper_test.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Od user32.lib /Fe:effect_wrapper_test.exe /Fo:effect_wrapper_test.obj "effect_wrapper_test.cpp"
if errorlevel 1 exit /b 1
effect_wrapper_test.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Od user32.lib /Fe:retention_test.exe /Fo:retention_test.obj "retention_test.cpp"
if errorlevel 1 exit /b 1
retention_test.exe
if errorlevel 1 exit /b 1
exit /b 0









