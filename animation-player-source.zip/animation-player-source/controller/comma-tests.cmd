@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT comma_test.cpp /Fe:comma_test.exe
if errorlevel 1 exit /b 1
comma_test.exe
if errorlevel 1 exit /b 1
call run-tests.cmd
