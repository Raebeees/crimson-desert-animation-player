# Animation Player source snapshot

Snapshot of the paired animation menu and shared host used for the November 11, 2026 eight-entry Options test. Source, headers, tests, original build scripts and MinHook source/license are included for review. Not a complete playable or reproducible release. No game assets, audio, compiled plugins, personal logs, installation manifests or third-party game/mod sources are included.

## Design

The menu client and host communicate through a versioned interface. The host checks actor identity and readiness and coordinates the game animation route; the client manages selection, playback and audio. The shared host carries Tidebreaker integration because both features use overlapping runtime infrastructure. Lifecycle state and request tokens keep start/stop and actor changes bounded. Private animation routes are used to avoid globally replacing normal idle behavior. Version and asset checks exist because this integration is tied to particular game and mod builds.

## Tests and limits

On 2026-11-12, test-seven.cmd passed against this source snapshot: it simulates eight selections, lifecycle transitions and segmented playback. test-handoff.cmd compiled but failed at LoadLibrary because DanceModule.asi is not included and has not been built in this sanitized snapshot. Offline checks do not prove gameplay behavior. Other tests and scripts are included but were not run as part of this publication.

The build scripts retain their historical structure but local paths have been replaced with C:/Modding placeholders. They reference external adapter files and MinHook object files that are not supplied at those paths, and the original Visual Studio location must be adjusted. They are reference scripts, not a verified reproducible build. Runtime also requires matching game/mod versions and separately prepared animation and audio assets. Do not remove version or readiness guards to force loading.

The original project code's license is not specified in this snapshot. MinHook retains the license in controller/minhook/LICENSE.txt; third-party materials remain subject to their own terms.
