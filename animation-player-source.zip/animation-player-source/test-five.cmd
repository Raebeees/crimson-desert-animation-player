@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /std:c++17 /EHsc /W4 /WX /Icontroller /Icontroller\minhook\include test_five.cpp /Fe:test_five.exe
if errorlevel 1 exit /b 1
test_five.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX /Icontroller /Icontroller\minhook\include controller\idle_shared_test.cpp /Fe:bridge_test.exe /link user32.lib bcrypt.lib
if errorlevel 1 exit /b 1
bridge_test.exe
