@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /std:c++17 /EHsc /W4 /WX /I"%~dp0controller" test_handoff.cpp /Fe:test_handoff.exe
if errorlevel 1 exit /b 1
test_handoff.exe
