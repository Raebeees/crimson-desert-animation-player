@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0controller"
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT vertical_tuning_test.cpp /Fe:vertical_tuning_test.exe
if errorlevel 1 exit /b 1
vertical_tuning_test.exe
if errorlevel 1 exit /b 1
call run-tests.cmd
exit /b %errorlevel%
