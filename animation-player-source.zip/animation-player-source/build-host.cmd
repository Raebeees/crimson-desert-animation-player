@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /std:c++17 /EHsc /W4 /WX /O2 /MT /LD /I"C:\Modding\animation-dependencies\native-test" /I"C:\Modding\animation-dependencies\engine-adapter" /I"%~dp0controller" /I"%~dp0controller\minhook\include" bridge.cpp "C:\Modding\animation-dependencies\engine-adapter\hook.obj" "C:\Modding\animation-dependencies\engine-adapter\buffer.obj" "C:\Modding\animation-dependencies\engine-adapter\trampoline.obj" "C:\Modding\animation-dependencies\engine-adapter\hde64.obj" bcrypt.lib user32.lib /Fe:HostCandidate.asi /link /IMPLIB:HostCandidate.lib
