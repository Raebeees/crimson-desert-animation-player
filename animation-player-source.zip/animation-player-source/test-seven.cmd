@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
cl /nologo /std:c++17 /EHsc /W4 /WX /Icontroller /Icontroller\minhook\include test_seven.cpp /Fe:test_seven.exe
if errorlevel 1 exit /b 1
test_seven.exe
